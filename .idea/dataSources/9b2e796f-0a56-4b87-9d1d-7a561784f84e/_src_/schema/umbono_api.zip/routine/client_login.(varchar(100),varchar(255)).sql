CREATE PROCEDURE client_login(IN `__email` VARCHAR(100), IN `__password` VARCHAR(255))
  BEGIN 
 DECLARE __error_msg text;
 DECLARE __is_connected BOOLEAN DEFAULT FALSE;
 DECLARE __user_id   INT(50) DEFAULT NULL;
 SET AUTOCOMMIT = 0;
 START TRANSACTION;
  select id_user  INTO @curr_user_id FROM users  WHERE mail =  __email LIMIT 1;
 IF @curr_user_id IS NOT NULL THEN
   select mot_de_pass INTO @curr_password FROM users_login WHERE mot_de_pass = PASSWORD(__password) AND  id_user = @curr_user_id ORDER BY id_user_login DESC LIMIT 1;
      IF @curr_password IS NOT NULL THEN 
         SET __is_connected = TRUE;
         SET __error_msg = 'Connexion réussie';
         SET __user_id = @curr_user_id;
         SELECT nom, prenom, url_document INTO @nom, @prenom, @url_document FROM users, documents_users  WHERE  users.id_user = __user_id AND documents_users.id_user = __user_id LIMIT 1 ;

         
         
      ELSE
         SET __is_connected = FALSE;
         SET __error_msg = 'Mot de passe erronné';
      END IF;

  ELSE 
    SET __is_connected = FALSE;
    SET __error_msg = 'Email non enregistré';
 END IF ;
   SELECT __is_connected, __user_id, @nom, @prenom,@url_document,__error_msg;
 SET AUTOCOMMIT = 1;

 END;
