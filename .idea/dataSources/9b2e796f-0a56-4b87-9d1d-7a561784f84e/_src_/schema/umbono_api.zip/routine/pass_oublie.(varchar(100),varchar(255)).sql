CREATE PROCEDURE pass_oublie(IN `__email` VARCHAR(100), IN `__new_pass` VARCHAR(255))
  BEGIN
 UPDATE users_login SET mot_de_pass = PASSWORD (__new_pass) WHERE id_user = (SELECT id_user FROM users WHERE mail = __email LIMIT 1) LIMIT 1;
 
 SELECT COUNT(mot_de_pass) FROM users_login WHERE id_user = (SELECT id_user FROM users WHERE mail = __email LIMIT 1) LIMIT 1;

END;
