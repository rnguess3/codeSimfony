CREATE PROCEDURE modifie_info(IN `__id_user`   INT(50), IN `__nom` VARCHAR(100), IN `__prenom` VARCHAR(100),
                              IN `__telephone` VARCHAR(100), IN `__mail` VARCHAR(100), IN `__photo_url` VARCHAR(255))
  BEGIN
SET AUTOCOMMIT = 0;
UPDATE users SET nom = __nom, prenom = __prenom, mail = __mail, telephone = __telephone WHERE id_user = __id_user;

SELECT * FROM users WHERE id_user = __id_user;
SET AUTOCOMMIT = 1;

END;
