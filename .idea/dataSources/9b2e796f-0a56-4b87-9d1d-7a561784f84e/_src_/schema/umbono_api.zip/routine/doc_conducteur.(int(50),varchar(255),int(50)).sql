CREATE PROCEDURE doc_conducteur(IN `__type_document` INT(50), IN `__url_document` VARCHAR(255), IN `__id_user` INT(50))
  BEGIN 
DECLARE new_id_document int(50);
DECLARE error_msg text;

SET AUTOCOMMIT = 0;

START TRANSACTION;

SELECT id_documents INTO @curr_id_document FROM documents_users ORDER BY id_documents DESC LIMIT 1 FOR UPDATE;

IF @curr_id_document > 0 THEN
 SET new_id_document = @curr_id_document + 1 ;

ELSE 
   SET new_id_document = 1 ;
END IF;
 INSERT  INTO documents_users(id_documents,url_document,type_document,id_user) VALUES (new_id_document, __url_document, __type_document, __id_user);

 SET error_msg = "Enregistrement ok !!";
SELECT error_msg;

SET AUTOCOMMIT = 1;

END;
