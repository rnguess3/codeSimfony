CREATE PROCEDURE register_conducteur(IN `__nom`         VARCHAR(100), IN `__prenom` VARCHAR(100),
                                     IN `__telephone`   VARCHAR(100), IN `__mail` VARCHAR(100),
                                     IN `__photo_url`   VARCHAR(255), IN `__id_type_conducteur` INT(50),
                                     IN `__mot_de_pass` VARCHAR(255))
  BEGIN
DECLARE new_user_id int(50);
DECLARE new_conducteur_id int(50);
DECLARE new_id_documents int(50);
DECLARE new_type_photo int(255);
DECLARE new_id_user_login int(50); 
DECLARE error_msg text;

SET AUTOCOMMIT = 0;

START TRANSACTION;
SELECT id_documents INTO @curr_id_document FROM documents_users ORDER BY id_documents DESC LIMIT 1 FOR UPDATE; 
SELECT id_user_login INTO @curr_id_user_login FROM users_login ORDER BY id_user_login DESC LIMIT 1 FOR UPDATE;
SELECT id_user INTO @curr_user_id FROM users ORDER BY id_user DESC LIMIT 1 FOR UPDATE; 
SELECT id_conducteur INTO @curr_id_conducteur FROM  conducteur OrDER BY id_conducteur DESC LIMIT 1 FOR UPDATE;
SELECT count(*)  INTO @curr_mail FROM users  WHERE mail = __mail;
SELECT count(*)  INTO @curr_numero FROM users  WHERE  telephone= __telephone;

IF @curr_mail > 0 THEN 
  SET error_msg = "L'email est déja enregisté";
ELSEIF @curr_numero > 0 THEN
  SET error_msg = 'Le numero de telephone est déjà enregisté';

ELSE

IF @curr_id_document > 0 THEN
  SET new_id_documents = @curr_id_document + 1;
  ELSE
  SET new_id_documents = 1;
END IF;


IF @curr_user_id > 0 THEN
  SET new_user_id = @curr_user_id + 1;
  ELSE
  SET new_user_id = 1;
END IF;

IF @curr_id_user_login > 0 THEN
  SET new_id_user_login = @curr_id_user_login + 1;
  ELSE
  SET new_id_user_login = 1;
END IF;


IF @curr_id_conducteur > 0 THEN
  SET new_conducteur_id = @curr_id_conducteur + 1 ;
  ELSE 
  SET new_conducteur_id = 1;
END IF;

SET new_type_photo = 1;

INSERT INTO users(id_user,nom,prenom,telephone,mail) VALUES (new_user_id,__nom,__prenom,__telephone,__mail);

INSERT INTO documents_users(id_documents,url_document,type_document,id_user) VALUES (new_id_documents,__photo_url,new_type_photo,new_user_id);

INSERT INTO users_login(id_user_login,id_user,mot_de_pass) VALUES (new_id_user_login, new_user_id, PASSWORD(__mot_de_pass));

INSERT INTO conducteur(id_conducteur,id_user,id_type_conducteur) VALUES (new_conducteur_id, new_user_id, __id_type_conducteur);

SET error_msg = "enregistré avec succès";

END IF ;


SELECT error_msg;

SET AUTOCOMMIT = 1;

END;
